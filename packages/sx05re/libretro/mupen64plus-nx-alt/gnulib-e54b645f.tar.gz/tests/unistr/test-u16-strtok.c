/* Test of u16_strtok() function.
   Copyright (C) 2015-2021 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

#include <config.h>

#include "unistr.h"

#include <stdint.h>
#include <stdlib.h>

#include "macros.h"

#define UNIT uint16_t
#define U_STRTOK u16_strtok
#define U_UCTOMB u16_uctomb
#include "test-u-strtok.h"

int
main (void)
{
  test_u_strtok ();

  return 0;
}
